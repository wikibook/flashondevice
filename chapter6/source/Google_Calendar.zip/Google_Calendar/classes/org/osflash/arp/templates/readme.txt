Ariaware RIA Platform
Copyright � 2004 Aral Balkan. 

Copyright � 2004 Ariaware Limited.

This directory holds templates for common file types for use in your projects. These are templates in the traditional sense -- not classes based on the Template pattern.
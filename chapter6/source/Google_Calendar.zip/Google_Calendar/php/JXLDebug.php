<?php

	class JXLDebug
	{
		public static function debug($p_o)
		{
			echo($p_o . "<br />");
		}
		
		public static function debugHeader()
		{
			echo("---------------------<br />\n");
		}
	}

?>
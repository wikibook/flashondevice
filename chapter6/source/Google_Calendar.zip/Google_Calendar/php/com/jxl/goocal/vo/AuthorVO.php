<?php

	class AuthorVO
	{
		public $name;
		public $email;
	}

?>
<?php

	class WhenVO
	{
		public $startTime;
		public $endTime;
		public $reminder;
	}

?>